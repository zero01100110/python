print("Xin chào")
